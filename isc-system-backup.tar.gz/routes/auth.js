const express = require("express");
const router = express.Router();
const fs = require("fs");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const DB_PATH = "./database/db.json";
const SECRET = "isc_secret_key";

// ================= DB =================
function readDB() {
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// ================= REGISTER =================
router.post("/register", async (req, res) => {
  const db = readDB();

  const { nome, login, senha } = req.body;

  const existe = db.usuarios.find(u => u.login === login);
  if (existe) {
    return res.json({ erro: "Usuário já existe" });
  }

  const hash = await bcrypt.hash(senha, 10);

  db.usuarios.push({
    id: Date.now(),
    nome,
    login,
    senha: hash,
    criado_em: new Date().toISOString()
  });

  saveDB(db);

  res.json({ status: true });
});

// ================= LOGIN =================
router.post("/login", async (req, res) => {
  const db = readDB();

  const { login, senha } = req.body;

  const user = db.usuarios.find(u => u.login === login);

  if (!user) {
    return res.json({ erro: "Usuário não encontrado" });
  }

  const ok = await bcrypt.compare(senha, user.senha);

  if (!ok) {
    return res.json({ erro: "Senha inválida" });
  }

  const token = jwt.sign(
    { id: user.id, login: user.login },
    SECRET,
    { expiresIn: "7d" }
  );

  res.json({
    status: true,
    token
  });
});

module.exports = router;
