const express = require("express");
const router = express.Router();
const fs = require("fs");

const DB_PATH = "./database/db.json";

// ================= DB =================
function readDB() {
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// ================= LISTAR TODOS =================
router.get("/", (req, res) => {
  const db = readDB();
  res.json(db.imoveis);
});

// ================= CRIAR IMÓVEL =================
router.post("/", (req, res) => {
  const db = readDB();

  const { matricula, endereco, hidrometro, rota } = req.body;

  if (!matricula || !endereco) {
    return res.json({
      erro: "Matrícula e endereço são obrigatórios"
    });
  }

  const imovel = {
    id: Date.now(),

    matricula,
    endereco,
    hidrometro: hidrometro || null,
    rota: rota || null,

    visitado: false,

    created_at: new Date().toISOString(),
    updated_at: null,

    // controle operacional real
    sync_status: "pending"
  };

  db.imoveis.push(imovel);

  saveDB(db);

  res.json({
    status: true,
    imovel
  });
});

// ================= ATUALIZAR IMÓVEL =================
router.put("/:id", (req, res) => {
  const db = readDB();

  const imovel = db.imoveis.find(i => i.id == req.params.id);

  if (!imovel) {
    return res.json({ erro: "Imóvel não encontrado" });
  }

  const { matricula, endereco, hidrometro, rota } = req.body;

  if (matricula) imovel.matricula = matricula;
  if (endereco) imovel.endereco = endereco;
  if (hidrometro) imovel.hidrometro = hidrometro;
  if (rota) imovel.rota = rota;

  imovel.updated_at = new Date().toISOString();
  imovel.sync_status = "updated";

  saveDB(db);

  res.json({
    status: true,
    imovel
  });
});

// ================= MARCAR COMO VISITADO =================
router.patch("/:id/visitado", (req, res) => {
  const db = readDB();

  const imovel = db.imoveis.find(i => i.id == req.params.id);

  if (!imovel) {
    return res.json({ erro: "Imóvel não encontrado" });
  }

  imovel.visitado = true;
  imovel.updated_at = new Date().toISOString();
  imovel.sync_status = "updated";

  saveDB(db);

  res.json({
    status: true,
    imovel
  });
});

// ================= DELETAR IMÓVEL =================
router.delete("/:id", (req, res) => {
  const db = readDB();

  db.imoveis = db.imoveis.filter(i => i.id != req.params.id);

  saveDB(db);

  res.json({
    status: true
  });
});

// ================= ROTA INTELIGENTE =================
router.get("/ordenados", (req, res) => {
  const db = readDB();

  const pendentes = db.imoveis.filter(i => !i.visitado);
  const visitados = db.imoveis.filter(i => i.visitado);

  pendentes.sort((a, b) => a.id - b.id);

  const ordenados = [...pendentes, ...visitados];

  res.json({
    total: db.imoveis.length,
    pendentes: pendentes.length,
    ordenados
  });
});

module.exports = router;
