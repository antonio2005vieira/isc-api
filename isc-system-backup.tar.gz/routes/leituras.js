const express = require("express");
const router = express.Router();
const fs = require("fs");

const DB_PATH = "./database/db.json";

// ================= DB =================
function readDB() {
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// ================= CRIAR LEITURA =================
router.post("/", (req, res) => {
  const db = readDB();

  const {
    imovel_id,
    leitura,
    latitude,
    longitude,
    foto
  } = req.body;

  // validação real
  if (!imovel_id || !leitura) {
    return res.json({
      erro: "Imóvel e leitura são obrigatórios"
    });
  }

  const imovel = db.imoveis.find(i => i.id == imovel_id);

  if (!imovel) {
    return res.json({
      erro: "Imóvel não encontrado"
    });
  }

  const novaLeitura = {
    id: Date.now(),

    imovel_id,
    leitura: Number(leitura),

    latitude: latitude || null,
    longitude: longitude || null,

    foto: foto || null,

    created_at: new Date().toISOString(),

    // estado operacional (IMPORTANTE PARA OFFLINE)
    sync_status: "pending"
  };

  db.leituras.push(novaLeitura);

  // marca imóvel como visitado automaticamente
  imovel.visitado = true;
  imovel.updated_at = new Date().toISOString();
  imovel.sync_status = "updated";

  saveDB(db);

  res.json({
    status: true,
    leitura: novaLeitura
  });
});

// ================= LISTAR LEITURAS =================
router.get("/", (req, res) => {
  const db = readDB();
  res.json(db.leituras);
});

// ================= LEITURAS POR IMÓVEL =================
router.get("/imovel/:id", (req, res) => {
  const db = readDB();

  const leituras = db.leituras.filter(
    l => l.imovel_id == req.params.id
  );

  res.json(leituras);
});

// ================= ATUALIZAR STATUS SYNC =================
router.patch("/:id/sync", (req, res) => {
  const db = readDB();

  const leitura = db.leituras.find(l => l.id == req.params.id);

  if (!leitura) {
    return res.json({ erro: "Leitura não encontrada" });
  }

  leitura.sync_status = "synced";

  saveDB(db);

  res.json({
    status: true
  });
});

module.exports = router;
