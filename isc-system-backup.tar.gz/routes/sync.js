const express = require("express");
const router = express.Router();
const fs = require("fs");

const DB_PATH = "./database/db.json";

// ================= DB =================
function readDB() {
  return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// ================= ENVIAR LOTE OFFLINE =================
router.post("/", (req, res) => {
  const db = readDB();

  const itens = Array.isArray(req.body) ? req.body : [req.body];

  const resultado = [];

  itens.forEach(item => {

    // validação mínima real
    if (!item.client_id || !item.tipo) {
      resultado.push({
        client_id: item.client_id || null,
        status: "erro",
        motivo: "dados inválidos"
      });
      return;
    }

    // evita duplicação (ESSENCIAL OFFLINE)
    const existe = db.sync_queue.find(
      s => s.client_id === item.client_id
    );

    if (existe) {
      resultado.push({
        client_id: item.client_id,
        status: "duplicado"
      });
      return;
    }

    // adiciona na fila de sync
    const syncItem = {
      id: Date.now() + Math.random(),
      client_id: item.client_id,

      tipo: item.tipo, // leitura | foto | imovel
      payload: item.payload || {},

      status: "pending",

      created_at: new Date().toISOString(),
      synced_at: null
    };

    db.sync_queue.push(syncItem);

    resultado.push({
      client_id: item.client_id,
      status: "enfileirado"
    });
  });

  saveDB(db);

  res.json({
    status: true,
    resultado
  });
});

// ================= PROCESSAR SINCRONIZAÇÃO =================
router.post("/process", (req, res) => {
  const db = readDB();

  const pendentes = db.sync_queue.filter(
    item => item.status === "pending"
  );

  const resultado = [];

  pendentes.forEach(item => {

    // marca como sincronizado
    item.status = "synced";
    item.synced_at = new Date().toISOString();

    // registra log
    db.sync_log.push({
      id: Date.now() + Math.random(),
      client_id: item.client_id,
      tipo: item.tipo,
      synced_at: item.synced_at
    });

    resultado.push({
      client_id: item.client_id,
      status: "sincronizado"
    });
  });

  saveDB(db);

  res.json({
    status: true,
    processados: resultado.length,
    resultado
  });
});

// ================= STATUS DA FILA =================
router.get("/status", (req, res) => {
  const db = readDB();

  const total = db.sync_queue.length;
  const pendentes = db.sync_queue.filter(i => i.status === "pending").length;
  const sincronizados = db.sync_queue.filter(i => i.status === "synced").length;

  res.json({
    total,
    pendentes,
    sincronizados
  });
});

module.exports = router;
