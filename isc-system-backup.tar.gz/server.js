const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

// ================= MIDDLEWARE =================
app.use(cors());
app.use(express.json());

// frontend (PWA)
app.use(express.static("public"));
app.use("/uploads", express.static("uploads"));

// ================= ROTAS =================
app.use("/auth", require("./routes/auth"));
app.use("/imoveis", require("./routes/imoveis"));
app.use("/leituras", require("./routes/leituras"));
app.use("/sync", require("./routes/sync"));
app.use("/mapa", require("./routes/mapa"));

// ================= START =================
app.listen(PORT, () => {
  console.log("✔ SERVIDOR RODANDO NA PORTA " + PORT);
});
